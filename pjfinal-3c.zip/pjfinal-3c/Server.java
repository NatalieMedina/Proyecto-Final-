import java.net.*;
import java.io.*;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.util.*;

 
public class Server{
    static int PUERTO;
    ServerSocket sc;
    Socket so;
    DataOutputStream salida;
    DataInputStream entrada;
    String mensajeRecibido;
 
    public void initServidor(int PUERTO){
         
        Scanner teclado = new Scanner(System.in);
        try{
            sc = new ServerSocket(PUERTO);
            so = new Socket();
             
            System.out.println("Esperando conexión...");
            so = sc.accept();
            System.out.println("Se conecto uno...");
            entrada = new DataInputStream(so.getInputStream());
            salida = new DataOutputStream(so.getOutputStream());
            String msn = "", STATEUSER="LOGOUT",STATESERVER="Offline"; 
            boolean condicional, condicional2;
            ManejoBD manejo = new ManejoBD();
            Manejoprueba manejo2 = new Manejoprueba();
            while(!msn.equals("EXIT")){ 
                mensajeRecibido = entrada.readUTF();//Leemos el mensaje del cliente


                System.out.println(mensajeRecibido);
                if(mensajeRecibido.substring(0,6).equals("LOGIN "))
                {
                    int l= (mensajeRecibido.length());
                    String ncorreo=mensajeRecibido.substring(6,l);
                    Scanner correo = new Scanner(ncorreo);
                    //correo.useDelimiter("[@]");
                    String username = correo.next();
                    String password = correo.next();
                    condicional= manejo.valuser(username);
                    if(condicional)
                    {
                        condicional2 = manejo.password(password);
                        if(condicional2){
                         //El password pertenece al usuario?     
                             salida.writeUTF("OK LOGIN");//Enviar respuesta a cliente
                            //Accion correspondiente a verificar si el contacto esta registrado
                             STATEUSER="Logged In";
                        }
                        else{salida.writeUTF("LOGIN ERROR 102 INVALID PASSWORD");}
                    } 
                    else{salida.writeUTF("LOGIN ERROR 101 UNKNOWN USER");}
                }




                else if(mensajeRecibido.substring(0,6).equals("CLIST ")){
                    int l=(mensajeRecibido.length());
                    String ncorreo=mensajeRecibido.substring(6,l);
                    //salida.writeUTF(manejo.clist(ncorreo));
                    Stack<String> list = new Stack<String>();
                    list=manejo.CLIST(ncorreo);
                    if(list.empty()){
                        salida.writeUTF("CLIST ERROR 103 NO CONTACTS FOUND");
                    }
                    else {
                        salida.writeUTF("OK CLIST");
                        salida.writeUTF(list.toString());
                    }
                    //Respuesta de confirmacion
                    //Accion correspondiente a enviar la lista de  contactos, desplegar lista de contactos, 
                    //el ultimo contacto con * 
                    
                }

                else if(mensajeRecibido.substring(0,12).equals("GETNEWMAILS ")){
                    // ManejoBD manejo = new ManejoBD();
       
                    int l=(mensajeRecibido.length());
                    String usuario=mensajeRecibido.substring(12,l);
                    //salida.writeUTF(manejo.clist(ncorreo));
                    Stack<String> list = new Stack<String>();
                    ArrayList<String> condicion1 = new ArrayList<String>();
                   condicion1= manejo.arreglosender(usuario);
                   ArrayList<String> condicion2 = new ArrayList<String>();
                 condicion2= manejo.arreglosubjet(usuario);
                 ArrayList<String> condicion3 = new ArrayList<String>();
                condicion3= manejo.arreglobody(usuario);
                String re= manejo2.getnewmails(condicion1,condicion2,condicion3);
     

                    list=manejo.CLIST(usuario);
                    if(re.equals(null)){
                        salida.writeUTF("OK GETNEWMAILS NOMAILS");
                    }
                    else {
                        salida.writeUTF("OK CLIST");
                        salida.writeUTF(re);
                    }
                    //salida.writeUTF(manejo.newmails(ncorreo));
                    salida.writeUTF("OK NEWMAILS");//Respuesta de confirmacion
                    
                }

                else if(mensajeRecibido.substring(0,10).equals("SEND MAIL ")){
                    //Accion correspondiente a enviar un nuevo mail
                     /* mailto = entrada.readUTF();
                        if (mailto.substring(0,8).equals("MAIL TO ")){
                            mensajeRecibido = entrada.readUTF() ;
                                
                        }*/
                        salida.writeUTF("OK SEND MAIL");//Respuesta de confirmacion
                        salida.writeUTF("Lo sentimos no lo implementamos :("); 
                }

                else if(mensajeRecibido.substring(0,8).equals("NEWCONT ")){
                    //Accion correspondiente a crear un nuevo contacto
                     int l= (mensajeRecibido.length());
                     String ncorreo=mensajeRecibido.substring(8,l);
                     Scanner correo = new Scanner(ncorreo);
                     correo.useDelimiter("[@]");
                     String username = correo.next();
                     String servername = correo.next();
                     if(servername.equals("servername")){
                     boolean ccondicional= manejo.newcont(ncorreo);
                     if (ccondicional){
                     salida.writeUTF("OK NEWCONT");//Respuesta de confirmacion
                     }
                     }
                     /*else if()
                     verificar si el servidor esta online y si este existe 
                     si no System.out.println("NEWCONT ERROR 110 SERVER NOT FOUND");
                     */
                     else{System.out.println("NEWCONT ERROR 109 CONTACT NOT FOUND "+mensajeRecibido);}
                    
                }

                else if(mensajeRecibido.substring(0,7).equals("LOGOUT ")){
                    //Accion correspondiente hacer del clinte un offline
                    STATEUSER="LOGOUT";
                    salida.writeUTF("OK LOGOUT");
                }

                else if(mensajeRecibido.substring(0,5).equals("NOOP ")){
                    salida.writeUTF("OK NOOP");//Respuesta de confirmacion
                    //Accion que permite a el cliente seguir conectado
                }

                else{
                    salida.writeUTF("INGRESO DE COMANDO ERRONERO REVISAR ENTRADA DEL CLIENTE");
                }
                /*System.out.println("Escriba un msn para enviar");
                msn = teclado.nextLine();
                salida.writeUTF(""+msn);//enviamos mensaje
                */
            }
            sc.close();
        }
        catch(Exception e){
 
        }
    }
 
    public static void main(String[] args){
        Server o = new Server();
        //System.out.println("Ingrese el puerto de conexion: ")
        o.initServidor(7000);
    }
 
}


