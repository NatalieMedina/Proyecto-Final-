import javax.swing.*;
public class PruebasDeGrafica{
	public static void main(String[] args) {
		Formulario formulario = new Formulario();
		formulario.setVisible(true);
		formulario.setBounds(0,0,400,300);
  		formulario.setResizable(false);
  		formulario.setVisible(true);
   		formulario.setLocationRelativeTo(null);

	}
}