import java.util.*;
import java.io.*;

public class Manejoprueba{

public String getnewmails(ArrayList<String> asender,ArrayList<String> asubjet,ArrayList<String> abody){
            int l= asender.size(); 
            String sender,subjet,body,all="";
            for(int i=0; i<l; i++){
                sender=asender.get(i);
                subjet=asubjet.get(i);
                body=abody.get(i);
                all=""+ all + sender + subjet + body ;
            }
            return all;
        }

     public static void main(String[] args){
        Scanner teclado = new Scanner(System.in); 
        ManejoBD manejo = new ManejoBD();
        System.out.println("Ingrese usuario");
        String usuario = teclado.nextLine();
        System.out.println(" :  "+usuario);
        ArrayList<String> condicion1 = new ArrayList<String>();
        condicion1= manejo.arreglosender(usuario);
        ArrayList<String> condicion2 = new ArrayList<String>();
        condicion2= manejo.arreglosubjet(usuario);
        ArrayList<String> condicion3 = new ArrayList<String>();
        condicion3= manejo.arreglobody(usuario);

        System.out.println("Algo:"+condicion1+" "+condicion2+" "+condicion3);
        
     Manejoprueba m= new Manejoprueba();
     m.getnewmails(condicion1,condicion2,condicion3);
        
    }

}