import javax.swing.*;
import java.awt.event.*;

public class Formulario extends JFrame implements ActionListener{

  private JLabel label1;
  private JLabel label2;
  private JTextField textfield1;
  private JButton boton1;

  public Formulario(){
    setLayout(null);
    label1 = new JLabel("Login");
    label1.setBounds(150,30,300,50);
    label1.setFont(new java.awt.Font("Arial", 1, 40));
    add(label1);

    label2 = new JLabel("Igrese su usuario y servidor");
    label2.setBounds(125,100,200,30);
    label2.setFont(new java.awt.Font("Tahoma", 1, 12));
    add(label2);

    textfield1 = new JTextField();
    textfield1.setBounds(110,150,200,30);
    add(textfield1);

    boton1 = new JButton("Aceptar");
    boton1.setBounds(150,200,100,30);
    add(boton1);
    boton1.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e){
    Formulario2 next = new Formulario2();
    next.setVisible(true);
    next.setVisible(true);
    next.setBounds(0,0,400,250);
    next.setLocationRelativeTo(null);
    next.setResizable(false);
    this.setVisible(false);
  } 

  public static void main(String args[]){
    Formulario formulario1 = new Formulario();
    formulario1.setBounds(0,0,400,300);
    formulario1.setResizable(false);
    formulario1.setVisible(true);
    formulario1.setLocationRelativeTo(null);
  }
}