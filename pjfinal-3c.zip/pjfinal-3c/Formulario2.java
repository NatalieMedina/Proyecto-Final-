import javax.swing.*;
import java.awt.event.*;

public class Formulario2 extends JFrame implements ActionListener{

  private JLabel label1;
  private JLabel label2;
  private JTextField textfield1;
  private JTextField textfield2;
  private JButton boton1;
  private JButton boton2;

  public Formulario2(){
    setLayout(null);
    label1 = new JLabel("USER: ");
    label1.setBounds(10,20,50,50);
    label1.setFont(new java.awt.Font("Tahoma", 1, 12));
    add(label1);

    label2 = new JLabel("PASSWORD: ");
    label2.setBounds(10,80,100,30);
    label2.setFont(new java.awt.Font("Tahoma", 1, 12));
    add(label2);

    textfield1 = new JTextField();
    textfield1.setBounds(120,30,200,30);
    add(textfield1);

    textfield2 = new JTextField();
    textfield2.setBounds(120,80,200,30);
    add(textfield2);

    boton1 = new JButton("Aceptar");
    boton1.setBounds(90,140,100,30);
    add(boton1);
    boton1.addActionListener(this);

    boton2 = new JButton("Anterior");
    boton2.setBounds(210,140,100,30);
    add(boton2);
    boton2.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e){
    if(e.getSource() == boton1) {
      Formulario3 next = new Formulario3();
      next.setVisible(true);
      next.setVisible(true);
      next.setBounds(0,0,400,370);
      next.setLocationRelativeTo(null);
      next.setResizable(false);
      this.setVisible(false);
    } else if(e.getSource() == boton2){
      Formulario previous = new Formulario();
      previous.setVisible(true);
      previous.setBounds(0,0,400,300);
      previous.setLocationRelativeTo(null);
      previous.setResizable(false);
      this.setVisible(false);
    }
  } 

  public static void main(String args[]){
    Formulario2 formulario2 = new Formulario2();
    formulario2.setBounds(0,0,400,250);
    formulario2.setResizable(false);
    formulario2.setVisible(true);
    formulario2.setLocationRelativeTo(null);
  }
}