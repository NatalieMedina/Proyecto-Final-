import javax.swing.*;
import java.awt.event.*;

public class Formulario4 extends JFrame implements ActionListener{

	private JLabel label1;
	private JLabel label2;
	private JButton boton1;
	private JButton boton2;
	private JTextField textfield1;
  	private JTextField textfield2;
	private JTextArea textarea1;

	public Formulario4(){

		setLayout(null);

		label1 = new JLabel("PARA :");
    	label1.setBounds(15,30,60,10);
    	label1.setFont(new java.awt.Font("Tahoma", 1, 12));
    	add(label1);

    	label2 = new JLabel("ASUNTO :");
    	label2.setBounds(15,75,60,10);
    	label2.setFont(new java.awt.Font("Tahoma", 1, 12));
    	add(label2);

    	textfield1 = new JTextField();
    	textfield1.setBounds(80,20,200,30);
    	add(textfield1);

    	textfield2 = new JTextField();
    	textfield2.setBounds(80,65,200,30);
    	add(textfield2);

    	textarea1 = new JTextArea();
  		textarea1.setBounds(15,120,370,200);
  		add(textarea1);

  		boton1 = new JButton("ENVIAR");
    	boton1.setBounds(90,340,100,30);
   	 	add(boton1);
    	//boton1.addActionListener(this);

    	boton2 = new JButton("Anterior");
    	boton2.setBounds(200,340,100,30);
   	 	add(boton2);
    	boton2.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e){
    if(e.getSource() == boton1) {
      
    } else if(e.getSource() == boton2){
      Formulario3 previous = new Formulario3();
      previous.setVisible(true);
      previous.setBounds(0,0,400,375);
      previous.setLocationRelativeTo(null);
      previous.setResizable(false);
      this.setVisible(false);
    }
  } 

	public static void main(String args[]){
    Formulario4 formulario4 = new Formulario4();
    formulario4.setBounds(0,0,400,450);
    formulario4.setResizable(false);
    formulario4.setVisible(true);
    formulario4.setLocationRelativeTo(null);
  }
}