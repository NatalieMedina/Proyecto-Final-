/*
Clase: Cliente
Integrantes: David Landaverde, Inigo Alvarado
*/



import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
/*Clase del cliente para que se conecte al servidor
con los comandos.*/


public class Client{


    static String HOST;
    static int PUERTO;
    Socket sc;
    DataOutputStream salida;
    DataInputStream entrada;
    String mensajeRecibido;
 
    public void initCliente(String HOST, int PUERTO){
        Scanner teclado = new Scanner(System.in);
        
        try{
            sc = new Socket(HOST, PUERTO);
            salida = new DataOutputStream(sc.getOutputStream());
            entrada = new DataInputStream(sc.getInputStream());
            String msn = "";
            
            while(!msn.equals("LOGOUT")){

                //System.out.println("")
                System.out.println("Escriba un comando para enviar");
                msn = teclado.nextLine();
                salida.writeUTF(msn);//enviamos mensaje
                mensajeRecibido = entrada.readUTF();//Leemos respuesta
                System.out.println(mensajeRecibido);
                if(mensajeRecibido.equals("OK LOGOUT")){
                  Pruebas email= new Pruebas("OK LOGOUT");
                  email.setVisible(true);
        
                    System.out.println("Se cerro la conexion");
                    msn="x";
                    sc.close();

                }else if(mensajeRecibido.equals("OK LOGIN")){
                  Pruebas email= new Pruebas("OK LOGIN");
                  email.setVisible(true);
                
                

                }
              else if(mensajeRecibido.equals("OK CLIST")){
                Pruebas email= new Pruebas("OK CLIST");
                  email.setVisible(true);
                 
                  
                }else if(mensajeRecibido.equals("OK NEWMAILS")){
                  Pruebas email= new Pruebas("OK NEWMAILS");
                  email.setVisible(true);
                

                }else if(mensajeRecibido.equals("OK SEND MAIL")){
                  Pruebas email= new Pruebas("OK SEND MAIL");
                  email.setVisible(true);
              

                }else if(mensajeRecibido.equals("OK NEWCONT")){
                  
                  Pruebas email= new Pruebas("OK NEWCONTr");
                  email.setVisible(true);
                  
 
                }
             
 
        }
        sc.close();
            
    }catch(Exception e){
        }
      }
    /*El main que se utiliza en esta clase
    y al correrlo se va desplegando en pantalla*/

    public static void main(String[] args) throws Exception{
        /*Separamos el usuario@server para compararlo con la base de datos*/

        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese correo de la forma username@servername: ");
         String sender = teclado.nextLine();
         int l= (sender.length());
         Scanner correo = new Scanner(sender);
         correo.useDelimiter("[@]");
         String username = correo.next();
         String servername = correo.next();
         ManejoBD manejo=new ManejoBD();
         String HOST = manejo.IP(servername);
         int PUERTO =7000;
        
     
          /*Diferentes condiciones de la conexion*/

              System.out.println("Ingrese puerto que quiere conectar");
              PUERTO=teclado.nextInt();
            if(manejo.Server(servername)){
             
             // formulario.setBounds(0,0,400,250);
             // formulario.setResizable(false);
             // formulario.setVisible(true);
             // formulario.setLocationRelativeTo(null);



              if(!HOST.equals("No obtenido")){
                  Client o = new Client();
                o.initCliente(HOST,PUERTO);
                
              } else{

              System.out.println("ERROR 105 UNKNOWN SERVER"); 
              }

           }else{
                System.out.println("ERROR 100 UNKNOWN SERVER");

           }

        

  }
}