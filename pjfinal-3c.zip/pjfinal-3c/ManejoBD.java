import java.net.*;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;
import java.util.concurrent.*;
public class ManejoBD{

  /**
*  PRTOCOLO PARA LA COMUNICACIÓN ENTRE LA BASE DE DATOS.
 * @author Cotto
  * @author Eduardo
 * @author Marco
 * @author Moi
 */

  //REVISION DE CONTRASEÑA VALIDA EN LA BASE DE DATOS
   public boolean password(String password){
    boolean condicion = false;

    try{
      DB conexion = new DB("testDb.db");
      if(conexion.connect()){

      }else{
        System.out.println("Error de conexion" + conexion.getError());
        System.exit(0);
      }

      boolean dato = conexion.executeQuery("SELECT Password FROM Usuarios WHERE Password LIKE " + "" + "'" + password + "'");
      String ip = (String)conexion.getString("Password");
      if(conexion.next() && ip.equals(password)){
        condicion = true;
      }
      conexion.close();
    }catch(Exception e){
      System.out.println(e.getClass());
      System.out.println(e.getMessage());
    }
    return condicion;
  }



  //revisa usuario
  public boolean valuser(String username){
    boolean condicion = false;

    try{
      DB conexion = new DB("testDb.db");
      if(conexion.connect()){
        
      }else{
        System.out.println("Error de conexion");
        System.exit(0);
      }
      boolean dato = conexion.executeQuery("SELECT Username FROM Usuarios WHERE Username LIKE" + " " + "'" + username + "'");
      if(conexion.next() && conexion.getString("Username").equals(username)){
        condicion = true;
      }
      conexion.close();

    }catch(Exception e){
      System.out.println(e.getClass());
      System.out.println(e.getMessage());
    }
    return condicion;
  }



  //retorna los contactos del user en una pila
  public  Stack<String> CLIST(String contactode){
         Stack<String> pila = new Stack<String>();
         String sender="Sender no encontrado", retorno="No hay contactos";
    try{
      DB conexion = new DB("testDb.db");//create one DB connection object
      
      if(!conexion.connect()){//create actual connection to db
        System.out.println("Error en db"+conexion.getError());
        System.exit(0);
      }
      String query = "SELECT Sender FROM Contactos WHERE Contacto_de LIKE"+ " " +"'"+ contactode+"'";
      boolean dato = conexion.executeQuery(query);
      while(conexion.next()){
       sender = (String)conexion.getString("Sender");
     
          sender = sender+" ";
          pila.push(sender);
      }
      pila.push("*");
      conexion.close();
    }catch(Exception e){
     System.out.println(e.getClass());
     System.out.println(e.getMessage());
    }

    return pila;
  }




   //DEVUELVE LOS CONTATOS DEL CONTATO COMO username
  public  ArrayList<String> arreglosender(String username){
         ArrayList<String> arreglo = new ArrayList<String>();
         String sender="Sender no encontrado", subjet="Subject no encontrado",body="Body no encontrado",resultado="-";
    try{
      DB conexion = new DB("testDb.db");//create one DB connection object
      
      if(!conexion.connect()){//create actual connection to db
        System.out.println("Error en db"+conexion.getError());
        System.exit(0);
      }
      String query = "SELECT Sender FROM Correos WHERE Contacto_de LIKE"+ " " +"'"+ username+"'";
      boolean dato = conexion.executeQuery(query);
      while(conexion.next()){
       sender = (String)conexion.getString("Sender");
          resultado = sender;
          arreglo.add(resultado);
      }
      arreglo.add("*");
      conexion.close();
    }catch(Exception e){
     System.out.println(e.getClass());
     System.out.println(e.getMessage());
    }

    return arreglo;
  }

 public  ArrayList<String> arreglosubjet(String username){
         ArrayList<String> arreglo = new ArrayList<String>();
         String sender="Sender no encontrado", subjet="Subject no encontrado",body="Body no encontrado",resultado="-";
    try{
      DB conexion = new DB("testDb.db");//create one DB connection object
      
      if(!conexion.connect()){//create actual connection to db
        System.out.println("Error en db"+conexion.getError());
        System.exit(0);
      }
      String query = "SELECT Subjet FROM Correos WHERE Contacto_de LIKE"+ " " +"'"+ username+"'";
      boolean dato = conexion.executeQuery(query);
      while(conexion.next()){
       sender = (String)conexion.getString("Subjet");
          resultado = sender;
          arreglo.add(resultado);
      }
      arreglo.add("*");
      conexion.close();
    }catch(Exception e){
     System.out.println(e.getClass());
     System.out.println(e.getMessage());
    }

    return arreglo;
  }

 public  ArrayList<String> arreglobody(String username){
         ArrayList<String> arreglo = new ArrayList<String>();
         String sender="Sender no encontrado", subjet="Subject no encontrado",body="Body no encontrado",resultado="-";
    try{
      DB conexion = new DB("testDb.db");//create one DB connection object
      
      if(!conexion.connect()){//create actual connection to db
        System.out.println("Error en db"+conexion.getError());
        System.exit(0);
      }
      String query = "SELECT Body FROM Correos WHERE Contacto_de LIKE"+ " " +"'"+ username+"'";
      boolean dato = conexion.executeQuery(query);
      while(conexion.next()){
       sender = (String)conexion.getString("Body");
          resultado = sender;
          arreglo.add(resultado);
      }
      arreglo.add("*");
      conexion.close();
    }catch(Exception e){
     System.out.println(e.getClass());
     System.out.println(e.getMessage());
    }

    return arreglo;
  }


  public boolean newcont(String sender){
    boolean retorno=false,dato=true;
    DB conexion = new DB("testDb.db");
    try{
    
    if(!conexion.connect()){
      System.out.println("Error en la conexion de la base de datos");
    }
    else{
      String querry= "INSERT INTO Contactos FROM Sender de WHERE Contacto_de LIKE"+" "+"'"+sender+"'";
      dato=conexion.executeQuery(querry);
      if(conexion.next()&& conexion.getString("Sender").equals(sender)){
      retorno= true;
      }
    }

    
    }catch(Exception e){
     System.out.println(e.getClass());
     System.out.println(e.getMessage());
    }
    return retorno;
  }

//validar el server
//idar Server
  public boolean Server(String servername){
    boolean condicion = false;

    try{
      DB conexion = new DB("testDb.db");

      if(conexion.connect()){

      }else{
        System.out.println("error de conexion" + conexion.getError());
        System.exit(0);
      }

      boolean dato = conexion.executeQuery("SELECT Servername FROM Servidores WHERE Servername LIKE" + " " + "'" + servername + "'");
      String ip = (String)conexion.getString("Servername");
      if(conexion.next() && ip.equals(servername)){
        condicion = true;
      }
      conexion.close();
    }catch(Exception e){
      System.out.println(e.getClass());
      System.out.println(e.getMessage());
    }
    return condicion;   
  }


    public String IP(String servername){
    String ip = "No obtenido";

    try{

      DB conexion = new DB("testDb.db");

      if(conexion.connect()){

      }else{
        System.out.println("error de conexion" + conexion.getError());
        System.exit(0);
      }

      boolean dato = conexion.executeQuery("SELECT IP FROM Servidores WHERE Servername LIKE"+ " " +"'"+ servername+"'");
      ip = (String)conexion.getString("IP");

      if (conexion.next() && ip.equals(servername)){
        ip = ip;
      }conexion.close();

    }catch(Exception e){
      System.out.println(e.getClass());
      System.out.println(e.getMessage());
    }
    return ip;
  }


  
}