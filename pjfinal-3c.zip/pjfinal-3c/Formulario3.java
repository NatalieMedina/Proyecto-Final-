import javax.swing.*;
import java.awt.event.*;

public class Formulario3 extends JFrame implements ActionListener{

	private JTextArea textarea1;
	private JButton boton1;
	private JButton boton2;
	private JButton boton3;
	private JButton boton4;
	private JButton boton5;

	public Formulario3(){
  		setLayout(null);

  		textarea1 = new JTextArea();
  		textarea1.setBounds(10,10,370,200);
  		add(textarea1);

  		boton1 = new JButton("Contactos");
    	boton1.setBounds(10,240,100,30);
   	 	add(boton1);
    	//boton1.addActionListener(this);

    	boton2 = new JButton("Nuevo Contacto");
    	boton2.setBounds(120,240,150,30);
    	add(boton2);
    	boton2.addActionListener(this);

    	boton3 = new JButton("Redactar");
    	boton3.setBounds(280,240,100,30);
    	add(boton3);
    	boton3.addActionListener(this);

    	boton4 = new JButton("Mensajes");
    	boton4.setBounds(70,280,100,30);
    	add(boton4);
    	//boton3.addActionListener(this);

    	boton5 = new JButton("Anterior");
    	boton5.setBounds(210,280,100,30);
    	add(boton5);
    	boton5.addActionListener(this);
  	}

  	public void actionPerformed(ActionEvent e){
  		if(e.getSource() == boton1) {
      	this.setVisible(false);
      }else if(e.getSource() == boton2){
        Nuevo next = new Nuevo();
        next.setVisible(true);
        next.setBounds(0,0,250,200);
        next.setLocationRelativeTo(null);
        next.setResizable(false);
        this.setVisible(false);

      }else if(e.getSource() == boton3){
        Formulario4 next = new Formulario4();
        next.setVisible(true);
        next.setVisible(true);
        next.setBounds(0,0,400,450);
        next.setLocationRelativeTo(null);
        next.setResizable(false);
        this.setVisible(false);

      } else if(e.getSource() == boton5){
      	Formulario2 previous = new Formulario2();
      	previous.setVisible(true);
      	previous.setBounds(0,0,400,250);
      	previous.setLocationRelativeTo(null);
      	previous.setResizable(false);
      	this.setVisible(false);
      }
  } 

  	public static void main(String args[]){
  		Formulario3 formulario3 = new Formulario3();
    	formulario3.setBounds(0,0,400,370);
    	formulario3.setResizable(false);
    	formulario3.setVisible(true);
    	formulario3.setLocationRelativeTo(null);
  }
}