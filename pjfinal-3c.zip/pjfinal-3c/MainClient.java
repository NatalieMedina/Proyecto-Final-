import java.util.*;
       public class MainClient{
       Scanner teclado = new Scanner(System.in);
      try{
          System.out.println("Ingrese correo de la forma username@servername: ");
          String sender = teclado.nextLine();
          int l= (sender.length());
          Scanner correo = new Scanner(sender);
         correo.useDelimiter("[@]");
         String username = correo.next();
         String servername = correo.next();
         ManejoBD manejo=new ManejoBD();
           String HOST = manejo.getip(servername);
          int PUERTO =0;
         

              System.out.println("Ingrese puerto que quiere conectar");
              PUERTO=teclado.nextInt();
            if(manejo.getserver(servername)){

              if(!HOST.equals("No obtenido")){
                Client o = new Client();
                o.initCliente(HOST,PUERTO);

              } else{

              System.out.println("ERROR 105 UNKNOWN SERVER"); 
              }

           }else{
                System.out.println("ERROR 100 UNKNOWN SERVER");

           }
     }catch(Exception e){}

         }
               
               //El usuario esta en la tabla?     
              //definir una variable de la ip del servidor y una para el puerto
      